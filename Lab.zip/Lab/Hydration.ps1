﻿Param(
  [string] [Parameter(Mandatory=$true)] $alias,
  [string] [Parameter(Mandatory=$true)] $adminpassword
)


$outputpath ="C:\Lab\hydrationoutput.txt"

Write-Host 'Please log into Azure now' -foregroundcolor Green;
Login-AzureRmAccount

$Subscription = (Get-AzureRmSubscription) |Select Name, Id | Out-GridView -Title "Select Azure Subscription " -PassThru

Select-AzureRmSubscription -SubscriptionName $Subscription.Name

$aadAppName =$alias +"msreadylabapp"

$defaultHomePage ="http://"+"$azureadappname"
$IDENTIFIERURI =[string]::Format("http://localhost:8080/{0}",[Guid]::NewGuid().ToString("N"));
$keyvaultrg =$alias+'-keyvault-rg'
$keyvaultName =$alias +'-akeyvault'
$omsname=$alias+'-omsready'
$omsrg= $alias+'-oms-rg'
$location ="East US"
$aadClientSecret = “abc123”



$function =@("keyvault","network","dc","ElbApp","Trafficmgrapp","oms","jumpbox")

        foreach ($rg in $function)

            {

                $rgname = $alias +'-'+ $rg+'-rg'
                New-AzureRmResourceGroup -Name $rgname -Location $Location | Out-Null
                Write-Host "Created Resource Group $rgname" -BackgroundColor Green -ForegroundColor DarkBlue 

            }

# Check if AAD app with $aadAppName was already created
    $SvcPrincipals = (Get-AzureRmADServicePrincipal -SearchString $aadAppName);
    if(-not $SvcPrincipals)
    {
        # Create a new AD application if not created before
        
        $now = [System.DateTime]::Now;
        $oneYearFromNow = $now.AddYears(1);
        $aadClientSecret = "abc123";

        Write-Host "Creating new AAD application ($aadAppName)";
        $ADApp = New-AzureRmADApplication -DisplayName $aadAppName -HomePage $defaultHomePage -IdentifierUris $identifierUri  -StartDate $now -EndDate $oneYearFromNow -Password $aadClientSecret;
        $servicePrincipal = New-AzureRmADServicePrincipal -ApplicationId $ADApp.ApplicationId;
        $SvcPrincipals = (Get-AzureRmADServicePrincipal -SearchString $aadAppName);
        if(-not $SvcPrincipals)
        {
            # AAD app wasn't created 
            Write-Error "Failed to create AAD app $aadAppName. Please log-in to Azure using Login-AzureRmAccount  and try again";
            return;
        }
        $aadClientID = $servicePrincipal.ApplicationId;
        Write-Host "Created a new AAD Application ($aadAppName) with ID: $aadClientID ";
    }
    else
    {


       $aadClientID = $SvcPrincipals[0].ApplicationId;
    }



 Try
        {
            $resGroup = Get-AzureRmResourceGroup -Name $keyvaultrg -ErrorAction SilentlyContinue;
        }
    Catch [System.ArgumentException]
        {
            Write-Host "Couldn't find resource group:  ($keyvaultrg)";
            $resGroup = $null;
        }
    
    #Create a new resource group if it doesn't exist
    if (-not $resGroup)
        {
            Write-Host "Creating new resource group:  ($keyvaultrg)";
            $resGroup = New-AzureRmResourceGroup -Name $keyvaultrg -Location $location;
            Write-Host "Created a new resource group named $keyvaultrg to place keyVault";
        }
    
    Try
        {
            $keyVault = Get-AzureRmKeyVault -VaultName $keyvaultName -ErrorAction SilentlyContinue;
        }
    Catch [System.ArgumentException]
        {
            Write-Host "Couldn't find Key Vault: $keyVaultName";
            $keyVault = $null;
        }
    
    #Create a new vault if vault doesn't exist
    if (-not $keyVault)
        {
            Write-Host "Creating new key vault:  ($keyVaultName)";
            $keyVault = New-AzureRmKeyVault -VaultName $keyVaultName -ResourceGroupName $keyvaultrg -Sku Standard -Location $location;
            Write-Host "Created a new KeyVault named $keyVaultName to store encryption keys";
        }
    # Specify privileges to the vault for the AAD application - https://msdn.microsoft.com/en-us/library/mt603625.aspx
    Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -ServicePrincipalName $aadClientID -PermissionsToKeys wrapKey -PermissionsToSecrets set;

    Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -EnabledForDiskEncryption -EnabledForTemplateDeployment;

    $diskEncryptionKeyVaultUrl = $keyVault.VaultUri;
	$keyVaultResourceId = $keyVault.ResourceId;

    $seckey1=ConvertTo-SecureString -String $adminpassword -AsPlainText -Force
    Set-AzureKeyVaultSecret -Name adminpassword -SecretValue $seckey1 -VaultName $keyvaultName 


Try
        {
            $omsworkspace = Get-AzureRmOperationalInsightsWorkspace -ResourceGroupName $omsrg -Name $omsname   -ErrorAction SilentlyContinue;
        }
    Catch [System.ArgumentException]
        {
            Write-Host "Couldn't find Oms Workspace:  ($omsname)";
            $omsworkspace = $null;
        }
    
    #Create a new OMS Workspace if it doesn't exist
    if (-not $omsworkspace)
        {
            Write-Host "Creating new OMS Workspace:  ($omsname)";
            $omsworkspace=New-AzureRmOperationalInsightsWorkspace -Location $location -Name $omsname -ResourceGroupName $omsrg  -Force -Sku free 
            Write-Host "Created a new OMS WorkSpace named $omsname for Monitoring and Log analytics";
        }


    $sharedkey=Get-AzureRmOperationalInsightsWorkspaceSharedKeys -Name $omsname -ResourceGroupName $omsrg

    $key=$sharedkey.PrimarySharedKey
    $omsclientid= $omsworkspace.CustomerId.Guid



    if((Test-Path  $outputpath) -eq 'True' )
        {
            Clear-Content $outputpath
        }
        Write-Output "aadClientID ----------" |Out-File $outputpath -Append 
        $aadClientID.Guid |Out-File $outputpath -Append
        Write-Output "`t`r`nOMS WorkSpace ID  ---------->>" |Out-File $outputpath -Append
        $omsclientid|Out-File $outputpath -Append
        Write-Output "`r`nOMS Shared Key  ---------->>>>" |Out-File $outputpath -Append
        $key|Out-File $outputpath -Append

Start $outputpath

Write-Host "Please note down below aadClientID, ,OMSWorkspace-Client-id, OMSSharedkey and refer these values in $outputpath  " -foregroundcolor Green;
    Write-Host "`t aadClientID: $aadClientID" -foregroundcolor Green;
    Write-Host "`t OMSWorkspaceID: $omsclientid" -foregroundcolor Green;
    Write-Host "`t OMSSharedKey: $key" -foregroundcolor Green;
    Write-Host "`t keyVaultNAme: $keyvaultName" -foregroundcolor Green;